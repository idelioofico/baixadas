<footer class="page-footer">
    <div class="font-13">2021 © <b>Tes-Top</b> - All rights reserved.</div>
    <div class="font-13">2021 © <b>Tes-Top</b></div>
    <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer>
